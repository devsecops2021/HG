// Added by CI Bootstrap 3
$(function(){
	$( 'textarea.texteditor' ).ckeditor({toolbar:'Full',width:700});
	$( 'textarea.mini-texteditor' ).ckeditor({toolbar:'Basic',width:700});
});