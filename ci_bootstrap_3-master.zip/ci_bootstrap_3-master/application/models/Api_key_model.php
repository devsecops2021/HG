<?php 

class Api_key_model extends MY_Model {
}