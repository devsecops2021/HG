<?php 

class Group_model extends MY_Model {
}