
<div class="container">
	<p>view file: /application/views/home.php</p>
</div>